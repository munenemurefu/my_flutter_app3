import 'package:flutter/material.dart';
import 'package:url_launcher/url_launcher.dart';
import 'package:share_plus/share_plus.dart';

void main() {
  runApp(const MatatuGoApp());
}

class MatatuGoApp extends StatelessWidget {
  const MatatuGoApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'MatatuGo',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(primarySwatch: Colors.green),
      home: const LoginPage(),
    );
  }
}

class LoginPage extends StatefulWidget {
  const LoginPage({super.key});

  @override
  State<LoginPage> createState() => _LoginPageState();
}

class _LoginPageState extends State<LoginPage> {
  final TextEditingController _usernameController = TextEditingController();
  final TextEditingController _passwordController = TextEditingController();

  void _login() {
    if (_usernameController.text == 'admin' && _passwordController.text == '1234') {
      Navigator.pushReplacement(context, MaterialPageRoute(builder: (_) => const HomePage()));
    } else {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Invalid username or password')),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Login')),
      body: Padding(
        padding: const EdgeInsets.all(20.0),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            TextField(controller: _usernameController, decoration: const InputDecoration(labelText: 'Username')),
            TextField(controller: _passwordController, decoration: const InputDecoration(labelText: 'Password'), obscureText: true),
            const SizedBox(height: 20),
            ElevatedButton(onPressed: _login, child: const Text('Login'))
          ],
        ),
      ),
    );
  }
}

class HomePage extends StatelessWidget {
  const HomePage({super.key});

  void _openPlayStore() async {
    final Uri url = Uri.parse('https://play.google.com/store/apps/details?id=com.example.matatugo');
    if (!await launchUrl(url, mode: LaunchMode.externalApplication)) {
      throw Exception('Could not launch $url');
    }
  }

  void _sendEmail() async {
    final Uri email = Uri(
      scheme: 'mailto',
      path: 'musanyicharlie@gmail.com',
      query: 'subject=MatatuGo Inquiry',
    );
    if (!await launchUrl(email)) {
      throw Exception('Could not launch email');
    }
  }

  void _shareApp() {
    Share.share('Check out the MatatuGo app: https://play.google.com/store/apps/details?id=com.example.matatugo');
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('MatatuGo')),
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            ElevatedButton(
              onPressed: () {
                Navigator.push(context, MaterialPageRoute(builder: (_) => const RoutesPage()));
              },
              child: const Text('MatatuGo'),
            ),
            ElevatedButton(onPressed: _openPlayStore, child: const Text('Rate Us')),
            ElevatedButton(onPressed: _sendEmail, child: const Text('Send Email')),
            ElevatedButton(onPressed: _shareApp, child: const Text('Share')),
            ElevatedButton(
              onPressed: () {
                Navigator.push(context, MaterialPageRoute(builder: (_) => const MapsPage()));
              },
              child: const Text('Google Maps Search'),
            ),
          ],
        ),
      ),
    );
  }
}

class RoutesPage extends StatelessWidget {
  const RoutesPage({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Bungoma Routes')),
      body: ListView(
        children: const [
          ExpansionTile(
            title: Text('Bungoma - Nairobi'),
            children: [ListTile(title: Text('Fare: Ksh 1000
Stops: Nakuru, Eldoret
Tips: Carry water'))],
          ),
          ExpansionTile(
            title: Text('Bungoma - Kisumu'),
            children: [ListTile(title: Text('Fare: Ksh 400
Stops: Kakamega, Luanda
Tips: Travel early'))],
          ),
        ],
      ),
    );
  }
}

class MapsPage extends StatelessWidget {
  const MapsPage({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Search Routes on Google Maps')),
      body: const Center(
        child: Text('Google Maps widget placeholder - Add your API key in AndroidManifest.xml'),
      ),
    );
  }
}
